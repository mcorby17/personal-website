/* A simple server in the internet domain using TCP
   The port number is passed as an argument */
   
// Why does encipher read the whole string but not decipher?
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <iostream>
#include "BCipher.cpp"
using namespace std;

void cipher(const char *);
void decipher(int intarray[]); //parameter after sizeOfArray works: int intArray[]
int * charToInt(const char *);
int sizeOfArray(int array[]);

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

int main(int argc, char *argv[])
{
     int sockfd, newsockfd, portno, n;
     socklen_t clilen;
     char buffer[256];
     struct sockaddr_in serv_addr, cli_addr;
	 bool done = false;
	 struct data_t{
		char cmd[1];
		char the_data[80];
	 };
	 data_t clientData;
	 int *intArray;
	
     if (argc < 2) {
         fprintf(stderr,"ERROR, no port provided\n");
         exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = atoi(argv[1]);
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0) 
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd, 
                 (struct sockaddr *) &cli_addr, 
                 &clilen);
     if (newsockfd < 0) 
          error("ERROR on accept");
	  
	 while(done == false){
		// Clear the struct
		bzero(clientData.cmd,1);
		bzero(clientData.the_data,80);
		
		n = read(newsockfd,clientData.cmd,1);
		if (n < 0) 
			error("ERROR reading from socket");
		
		if(clientData.cmd[0] == 'e'){
			write(newsockfd,"The server got your encipher request!",37);
			
			n = read(newsockfd,clientData.the_data,80);
			if (n < 0) 
				error("ERROR reading from socket");
			
			cipher(clientData.the_data);
		}
		else if(clientData.cmd[0] == 'd'){
			write(newsockfd,"The server got your decipher request!",37);
			
			n = read(newsockfd,clientData.the_data,80);
			if (n < 0) 
				error("ERROR reading from socket");
			
			//Test to see what the length is... appears to be reading in the whole string now 
			cout << "The length of the_data is: " << strlen(clientData.the_data) << endl;
			
			//Print out contents of clientData.the_data for testing purposes
			cout << "clientData.the_data: "; 
			for(int i=0; i < strlen(clientData.the_data); i++){
				cout << clientData.the_data[i];
			}
			cout << endl;
			
			//Convert char array to an int array
			intArray = charToInt(clientData.the_data);
			
			//Use the sizeOfArray to output all of the contents of the int array for testing purposes
			cout << "intArray: ";
			for(int y=0; y < sizeOfArray(intArray); y++){
				cout << *(intArray + y) << " ";
			}
			cout << endl;
			
			//Test to see if sizeOfArray works
			cout << "There are " << sizeOfArray(intArray) << " numbers in the entered array\n\n";
			
			//Decipher intArray
			decipher(intArray);
		}
		// Check if the client quit
		else if(clientData.cmd[0] == 'q'){
			write(newsockfd,"The server says goodbye!",24);
			done = true;
			break;
		}
	 } 
     
	 cout << "Client quit the program.\n";
	 
     close(newsockfd);
     close(sockfd);
     return 0; 
}

void cipher(const char *phrase){
	BCipher bealer;
	char letter;
	int  ciphervalue, i, inputsize = strlen(phrase);
	char inputchars[80];
	
	strcpy(inputchars,phrase);

	cout  << endl << "======================================" << 
	endl << "Following is an example of the encode method\n\n";
	for (i = 0; i < inputsize; i++){
		if (((inputchars[i] >= ASCIIa) && (inputchars[i] <= ASCIIz)) ||
		((inputchars[i] >= ASCIIA) && (inputchars[i] <= ASCIIZ)))
		{
			ciphervalue = bealer.encode(inputchars[i]);
			cout << inputchars[i] << ' ' << ciphervalue << endl;
		} // then letter is a-z OR A-Z
	} // for
}

// Needs to take this once you get sizeOfArray working: int intArray[]
void decipher(int intarray[]){
	BCipher bealer;
	char letter;
	int  i, decodesize = sizeOfArray(intarray); 
	int  thecipher[80]; //intArray; // Array must be initialized with enclosed brace?
	
	//Copy intarray to thecipher
	for(int j=0; j<decodesize; j++){
		thecipher[j] = intarray[j];
	}
	
	cout  << endl << "======================================" << 
    endl << "Following is an example of the decode method\n\n";
    for (i = 0; i <= decodesize; i++){
		letter = bealer.decode(thecipher[i]);
		cout << thecipher[i] << ' ' << letter << endl;
	} 
	cout << endl;
}

int * charToInt(const char *code){
	char tmp[5], nums[80]; //tmp holds each digit of a number. It is converted to an int when a space
	static int inums[10];  //is reached and then reset to 0's. Set to size of 4 since no code nums	
	int x=0,b=0;		   //are bigger than 4 digits
	
	bzero(inums,10);
	strcpy(nums,code);
		
	for(int a=0; a <= strlen(code); a++){
		if(nums[a] != ' ' && nums[a] != '\0'){ //While not a space or the end of the char array
			tmp[b] = nums[a];
			b++;
		}	
		else{
			inums[x] = atoi(tmp);
			x++;
			bzero(tmp,5); //Reset tmp to zero array
			b = 0; //Reset entry point of tmp			
		}
	}
	return inums;
}

int sizeOfArray(int array[]){
	int size = 0, i = 0;
	while(array[i] != '\0'){
		size++;
		i++;
	}
	return size;
}
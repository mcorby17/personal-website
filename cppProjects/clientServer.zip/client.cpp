#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <iostream>
using namespace std;
	
void error(const char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    int sockfd, portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    char buffer[4000];				  //Where typed in words are stored
    bool done = false;                //determines when to break out of the do while loop
	struct data_t{
		char cmd[1];
		char the_data[80];
	 };
	data_t data;

    portno = atoi(argv[1]); 					  
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	
    if (sockfd < 0)
        error("ERROR opening socket");
	else
		cout << "The socket was opened!\n";
	
    server = gethostbyname("127.0.0.1");  //localhost
	
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        exit(0);
    }
	
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
	
    bcopy((char *)server->h_addr,
         (char *)&serv_addr.sin_addr.s_addr,
         server->h_length);
    serv_addr.sin_port = htons(portno);
	
    if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
        error("ERROR connecting");

    n = write(sockfd,buffer,strlen(buffer));
    if (n < 0)
		error("ERROR writing to socket");
	else
		cout << "I wrote to the socket!\n";

//Begin functionality
	do{
		cout << "What function would you like to use? (e, d, or q): "; 
		cin >> data.cmd;
		
		// ENCIPHER
		if(data.cmd[0] == 'e' || data.cmd[0] == 'E'){ 
			
			bzero(data.the_data,80); // Reset 'the_data' to a zero-array	
			
			//Send the cmd to the server
			n = write(sockfd,data.cmd,1);
			if (n < 0)
				error("ERROR writing to socket");
			
			// Read the "got request" message from the server
			n = read(sockfd,buffer,255);
			if (n < 0) 
				error("ERROR reading from socket");
			
			// Print "got request" message
			printf("%s\n",buffer);
			
			//Ask for user input
			cin.ignore();
			cout << "Enter a phrase to encipher: ";
			cin.getline(data.the_data,80);
			
			//Test to see what the length of the entered string is
			//cout << "The length of the entered data is: " << strlen(data.the_data) << endl;
			
			//Send the message to the server
			n = write(sockfd,data.the_data,strlen(data.the_data));
			if (n < 0)
				error("ERROR writing to socket");		
			
			// Reset 'the_data' and 'cmd' to a zero-array
			//bzero(data.the_data,80); 
			bzero(data.cmd,1); 		 
		}
		// DECIPHER
		else if(data.cmd[0] == 'd' || data.cmd[0] == 'D'){ 
			
			bzero(data.the_data,80); // Reset 'the_data' to a zero-array		
			
			//Send the cmd to the server
			n = write(sockfd,data.cmd,1);
			if (n < 0)
				error("ERROR writing to socket");
			
			// Read the message from the server
			n = read(sockfd,buffer,255);
			if (n < 0) 
				error("ERROR reading from socket");
			
			// Print "got request" message
			printf("%s\n",buffer);
			
			// Ask for user input
			// Returns an initial prompt for every number I enter?
			cin.ignore();
			cout << "Enter an enciphered message to decipher: ";
			cin.getline(data.the_data,80);
			
			//Test to see what the length of the entered string is
			cout << "The length of the entered data is: " << strlen(data.the_data) << endl;
			
			//Send the message to the server
			n = write(sockfd,data.the_data,strlen(data.the_data));
			if (n < 0)
				error("ERROR writing to socket");		
			
			// Reset 'the_data' and 'cmd' to a zero-array
			//bzero(data.the_data,80); 
			bzero(data.cmd,1); 		 		
		}
		// QUIT
		else if(data.cmd[0] == 'q' || data.cmd[0] == 'Q'){ 
			bzero(data.the_data,80); // Reset 'buffer' to a zero-array
			bzero(buffer,4000);
			
			//Send the letter 'q' to the server
			n = write(sockfd,data.cmd,1);
			if (n < 0)
				error("ERROR writing to socket");
			
			// Close the socket and check that it's closed. read() will return -1 if the socket closed.
			n = read(sockfd,buffer,4000); 	
			printf("%s\n",buffer);
			if(n > 0){
				close(sockfd);
				cout << "Closed the socket" << endl;
			}								
			else
				error("Socket was not closed!");
		
			done = true;
		}
	} while(done != true);

    return 0;
}
